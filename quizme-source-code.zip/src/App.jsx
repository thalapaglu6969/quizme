
import React, { useState, useEffect } from 'react'
import './App.css'
import { motion } from 'framer-motion'

const questions = [
  {
    question: "Who painted the Mona Lisa?",
    options: ["Van Gogh", "Picasso", "Da Vinci", "Rembrandt"],
    answer: "Da Vinci"
  },
  {
    question: "What is the capital of France?",
    options: ["London", "Paris", "Berlin", "Rome"],
    answer: "Paris"
  }
]

function App() {
  const [current, setCurrent] = useState(0)
  const [score, setScore] = useState(0)
  const [selected, setSelected] = useState(null)
  const [showAnswer, setShowAnswer] = useState(false)

  const handleAnswer = (option) => {
    setSelected(option)
    setShowAnswer(true)
    if (option === questions[current].answer) {
      setScore(score + 1)
    }
    setTimeout(() => {
      setCurrent(current + 1)
      setSelected(null)
      setShowAnswer(false)
    }, 1500)
  }

  if (current >= questions.length) {
    return <div className="end">Quiz Over! Score: {score}/{questions.length}</div>
  }

  return (
    <div className="quiz">
      <motion.h2 initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        {questions[current].question}
      </motion.h2>
      <div className="options">
        {questions[current].options.map((opt, i) => (
          <motion.button
            whileHover={{ scale: 1.05 }}
            key={i}
            className={`option ${showAnswer && opt === questions[current].answer ? 'correct' : ''} 
              ${showAnswer && opt === selected && opt !== questions[current].answer ? 'wrong' : ''}`}
            onClick={() => handleAnswer(opt)}
            disabled={showAnswer}
          >
            {opt}
          </motion.button>
        ))}
      </div>
    </div>
  )
}

export default App
